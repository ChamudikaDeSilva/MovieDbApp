<div >
	<h1>Welcome to GoodView.com</h2>

<?php
	echo 'Hi '.$_COOKIE['loginuser'];
?>

	<a href="logout.php">Logout</a>
	<hr>
</div>
